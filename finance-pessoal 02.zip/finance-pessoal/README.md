# 💰 Finance Pessoal

Dashboard de finanças pessoais e conjuntas — conectado ao Notion com busca automática por nome do mês.

## Setup

```bash
git clone https://github.com/seu-usuario/finance-pessoal.git
cd finance-pessoal
npm install
cp .env.local.example .env.local
# Preencha NOTION_TOKEN no .env.local
npm run dev
```

## Variáveis de ambiente

Apenas **3 variáveis** necessárias no Vercel:

| Variável | Valor |
|---|---|
| `NOTION_TOKEN` | `secret_...` (seu token) |
| `NOTION_PESSOAL_PAGE_ID` | `36f74c88-0981-811d-be79-cc3ba42721fe` |
| `NOTION_CONJUNTA_PAGE_ID` | `36f74c88-0981-8174-970d-e659aa2e45ef` |

## Como funciona a busca automática

O app busca os databases pelo **nome do mês** dentro das páginas 2026.
Quando criar 2027, basta criar uma nova página "📅 2027" dentro de Pessoal ou Conjunta com os meses — o app reconhece automaticamente.

## Estrutura Notion

```
💰 Finanças
├── 👤 Pessoal
│   └── 📅 2026
│       └── Janeiro → Dezembro
└── 👫 Conjunta
    └── 📅 2026
        └── Janeiro → Dezembro
```

## Seções do app

- **Dashboard** — resumo, gráficos por categoria e grupo
- **Transações** — tabela completa com filtros
- **Recorrentes** — gastos fixos (lançados vs pendentes)
- **Comparativo** — comparação entre meses
- **Metas** — planejamento e acompanhamento
- **Relatórios** — visão anual consolidada (pessoal + conjunta)
