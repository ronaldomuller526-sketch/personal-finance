# 💰 Finance Pessoal

Dashboard de finanças pessoais conectado ao Notion, construído com Next.js 14 e React.

## Funcionalidades

- **Dashboard** — cards de resumo, gráficos por categoria e por grupo
- **Transações** — tabela completa com filtros por tipo e categoria
- **Recorrentes** — controle de gastos fixos (lançados vs pendentes)
- **Comparativo** — comparação entre meses
- **Metas** — planejamento e acompanhamento de metas financeiras
- **Relatórios** — visão anual consolidada com top categorias
- **Conta Conjunta** — seção preparada para adicionar

## Configuração

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/finance-pessoal.git
cd finance-pessoal
npm install
```

### 2. Configure as variáveis de ambiente
```bash
cp .env.local.example .env.local
```
Edite o `.env.local` com seu token do Notion e os IDs das databases.

### 3. Rode localmente
```bash
npm run dev
```
Acesse http://localhost:3000

## Deploy no Vercel

1. Faça push do código para o GitHub
2. Acesse vercel.com e importe o repositório
3. Em **Settings > Environment Variables**, adicione todas as variáveis do `.env.local.example`
4. Deploy automático!

## Variáveis de ambiente necessárias

| Variável | Descrição |
|----------|-----------|
| `NOTION_TOKEN` | Token da integração do Notion (`secret_...`) |
| `NOTION_JANEIRO` | ID da database de Janeiro |
| `NOTION_FEVEREIRO` | ID da database de Fevereiro |
| ... | (um para cada mês) |

## Estrutura do projeto

```
finance-pessoal/
├── app/
│   ├── page.tsx              → Seleção de perfil
│   ├── pessoal/page.tsx      → Dashboard pessoal
│   ├── conjunta/page.tsx     → Conta conjunta (em breve)
│   ├── metas/page.tsx        → Metas e planejamento
│   ├── relatorios/page.tsx   → Relatórios anuais
│   └── api/
│       ├── transacoes/       → GET transações do Notion
│       └── criar/            → POST nova transação
├── components/
│   └── Dashboard.tsx         → Dashboard principal
├── lib/
│   └── notion.ts             → Integração com Notion API
└── .env.local.example        → Template de variáveis
```

## Adicionando conta conjunta

1. Crie as databases no Notion para a conta conjunta
2. Adicione as variáveis `NOTION_CONJUNTA_*` no Vercel
3. Me peça para atualizar o componente `/app/conjunta/page.tsx`
