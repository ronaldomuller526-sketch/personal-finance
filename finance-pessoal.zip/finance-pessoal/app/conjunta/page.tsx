import Link from 'next/link'

export default function ConjuntaPage() {
  return (
    <div className="home-screen">
      <div className="home-card">
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👫</div>
        <h1 className="home-title">Conta Conjunta</h1>
        <p className="home-sub" style={{ marginBottom: '2rem' }}>
          Esta seção está reservada para as finanças compartilhadas entre você e sua esposa.
          Configure as databases do Notion para conta conjunta e ative esta seção.
        </p>
        <div style={{ background: 'var(--green-light)', border: '1px solid var(--green)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', textAlign: 'left', fontSize: '0.825rem', color: 'var(--green-dark)' }}>
          <strong>Para ativar:</strong> adicione as variáveis <code>NOTION_CONJUNTA_*</code> no Vercel com os IDs das databases da conta conjunta.
        </div>
        <Link href="/" className="btn-primary" style={{ justifyContent: 'center' }}>← Voltar ao início</Link>
      </div>
    </div>
  )
}
