'use client'

import { useState, useEffect, useRef } from 'react'
import { Chart, registerables } from 'chart.js'
import {
  MONTHS, CAT_COLOR, CAT_GRUPO_PESSOAL, CAT_GRUPO_CONJUNTA,
  CATS_PESSOAL, CATS_CONJUNTA, RECORRENTES_PESSOAL,
  calcResumo, fmt, type Transacao
} from '@/lib/notion'

Chart.register(...registerables)

interface Props { perfil: 'pessoal' | 'conjunta' }

export default function Dashboard({ perfil }: Props) {
  const isConj = perfil === 'conjunta'
  const CATS = isConj ? CATS_CONJUNTA : CATS_PESSOAL
  const CAT_GRUPO = isConj ? CAT_GRUPO_CONJUNTA : CAT_GRUPO_PESSOAL
  const label = isConj ? 'Conjunta' : 'Pessoal'
  const accent = isConj ? 'var(--purple)' : 'var(--green)'

  const [month, setMonth] = useState(() => {
    const m = new Date().getMonth()
    return MONTHS[m] || 'Fevereiro'
  })
  const [dbId, setDbId]   = useState<string | null>(null)
  const [data, setData]   = useState<Transacao[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab]     = useState<'dashboard'|'transacoes'|'recorrentes'|'comparativo'>('dashboard')
  const [showModal, setShowModal] = useState(false)
  const [filterTipo, setFilterTipo] = useState('')
  const [filterCat, setFilterCat]   = useState('')
  const [filterResp, setFilterResp] = useState('')
  const [compareData, setCompareData] = useState<any>(null)
  const pieRef  = useRef<HTMLCanvasElement>(null)
  const compRef = useRef<HTMLCanvasElement>(null)
  const pieChart  = useRef<Chart|null>(null)
  const compChart = useRef<Chart|null>(null)

  async function resolveDbId(m: string): Promise<string | null> {
    const res = await fetch(`/api/meses?month=${encodeURIComponent(m)}&perfil=${perfil}`)
    const json = await res.json()
    return json.dbId || null
  }

  async function loadMonth(m = month) {
    setLoading(true)
    setData([])
    const id = await resolveDbId(m)
    setDbId(id)
    if (id) {
      const res  = await fetch(`/api/transacoes?dbId=${id}&perfil=${perfil}`)
      const json = await res.json()
      setData(Array.isArray(json) ? json : [])
    }
    setLoading(false)
  }

  useEffect(() => { loadMonth(month) }, [month])

  // Pie chart
  useEffect(() => {
    if (tab !== 'dashboard' || loading || !pieRef.current) return
    const grupos = { azul: 0, vermelho: 0, verde: 0, cinza: 0 }
    data.filter(d => d.tipo === 'Despesa').forEach(d => {
      const g = CAT_GRUPO[d.cat] as keyof typeof grupos
      if (g) grupos[g] += d.valor
    })
    if (pieChart.current) pieChart.current.destroy()
    pieChart.current = new Chart(pieRef.current, {
      type: 'doughnut',
      data: {
        labels: ['Essencial','Discricionário','Renda','Individual'],
        datasets: [{ data: [grupos.azul, grupos.vermelho, grupos.verde, grupos.cinza], backgroundColor: ['#378ADD','#E24B4A','#1D9E75','#888780'], borderWidth: 0 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    })
  }, [tab, data, loading])

  // Compare chart
  useEffect(() => {
    if (tab !== 'comparativo') return
    loadCompare()
  }, [tab])

  useEffect(() => {
    if (!compareData || !compRef.current) return
    if (compChart.current) compChart.current.destroy()
    compChart.current = new Chart(compRef.current, {
      type: 'bar',
      data: {
        labels: compareData.labels,
        datasets: [
          { label: 'Entradas',      data: compareData.entradas, backgroundColor: '#1D9E75' },
          { label: 'Saídas',        data: compareData.saidas,   backgroundColor: '#E24B4A' },
          { label: 'Investimentos', data: compareData.invests,  backgroundColor: '#378ADD' },
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { x: { ticks: { autoSkip: false } }, y: { ticks: { callback: (v: any) => 'R$' + Number(v/1000).toFixed(0) + 'k' } } }
      }
    })
  }, [compareData])

  async function loadCompare() {
    const labels: string[] = [], entradas: number[] = [], saidas: number[] = [], invests: number[] = []
    for (const m of MONTHS) {
      try {
        const id = await resolveDbId(m)
        if (!id) continue
        const res  = await fetch(`/api/transacoes?dbId=${id}&perfil=${perfil}`)
        const json: Transacao[] = await res.json()
        if (!Array.isArray(json) || !json.length) continue
        const r = calcResumo(json)
        labels.push(m.substring(0,3))
        entradas.push(+r.entradas.toFixed(2))
        saidas.push(+r.saidas.toFixed(2))
        invests.push(+r.invest.toFixed(2))
      } catch {}
    }
    setCompareData({ labels, entradas, saidas, invests })
  }

  const { entradas, saidas, invest, saldo } = calcResumo(data)
  const catTotais: Record<string,number> = {}
  data.filter(d => d.tipo==='Despesa').forEach(d => { catTotais[d.cat] = (catTotais[d.cat]||0)+d.valor })
  const maxCat = Math.max(...Object.values(catTotais), 1)

  const cats = [...new Set(data.map(d => d.cat))].filter(Boolean)
  let txData = [...data]
  if (filterTipo) txData = txData.filter(d => d.tipo===filterTipo)
  if (filterCat)  txData = txData.filter(d => d.cat===filterCat)
  if (filterResp) txData = txData.filter(d => d.responsavel===filterResp)
  txData.sort((a,b) => (b.dataGasto||b.dataPag||'').localeCompare(a.dataGasto||a.dataPag||''))

  const nomes = data.map(d => d.desc.toLowerCase())

  return (
    <div style={{ minHeight:'100vh' }}>
      <div className="header">
        <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
          <div className="header-logo">
            💰 <span style={{ color: accent }}>{label}</span>
          </div>
          <div className="month-selector">
            <select value={month} onChange={e => setMonth(e.target.value)}>
              {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display:'flex', gap:'.75rem' }}>
          <button className="btn-primary" style={{ background: accent }} onClick={() => setShowModal(true)}>
            + Novo lançamento
          </button>
          <a href="/" className="btn-ghost">← Início</a>
        </div>
      </div>

      <div className="main">
        <div className="nav-tabs">
          {(['dashboard','transacoes','recorrentes','comparativo'] as const).map(t => (
            <button key={t} className={`nav-tab ${tab===t?'active':''}`}
              style={tab===t?{ background: accent }:{}}
              onClick={() => setTab(t)}>
              {t==='dashboard'?'📊 Dashboard':t==='transacoes'?'📋 Transações':t==='recorrentes'?'🔄 Recorrentes':'📈 Comparativo'}
            </button>
          ))}
        </div>

        {loading && <div className="loading"><div className="spinner"></div> Carregando {month}...</div>}

        {/* DASHBOARD */}
        {!loading && tab==='dashboard' && (
          <>
            <div className="summary-grid">
              <div className="summary-card"><div className="card-indicator ind-green"></div><div className="label">Entradas</div><div className="value" style={{color:'var(--green-dark)'}}>{fmt(entradas)}</div><div className="sub">{data.filter(d=>d.tipo==='Receita').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-red"></div><div className="label">Saídas</div><div className="value" style={{color:'var(--red)'}}>{fmt(saidas)}</div><div className="sub">{data.filter(d=>d.tipo==='Despesa').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-blue"></div><div className="label">Investimentos</div><div className="value" style={{color:'var(--blue-dark)'}}>{fmt(invest)}</div><div className="sub">{data.filter(d=>d.tipo==='Investimento').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-gray"></div><div className="label">Saldo</div><div className="value" style={{color:saldo>=0?'var(--green-dark)':'var(--red)'}}>{fmt(saldo)}</div><div className="sub">{saldo>=0?'Positivo':'Negativo'}</div></div>
            </div>
            <div className="dashboard-grid">
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Saídas por categoria</span><span className="chart-card-sub">{fmt(saidas)}</span></div>
                <div className="cat-list">
                  {Object.entries(catTotais).sort((a,b)=>b[1]-a[1]).map(([cat,val]) => (
                    <div key={cat} className="cat-item">
                      <div className="cat-dot" style={{background:CAT_COLOR[cat]||'#888'}}></div>
                      <span className="cat-name">{cat}</span>
                      <div className="cat-bar-wrap"><div className="cat-bar" style={{width:`${(val/maxCat*100).toFixed(0)}%`,background:CAT_COLOR[cat]||'#888'}}></div></div>
                      <span className="cat-value">{fmt(val)}</span>
                    </div>
                  ))}
                  {!Object.keys(catTotais).length && <div className="empty">Nenhuma saída registrada</div>}
                </div>
              </div>
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Distribuição por grupo</span></div>
                <div style={{position:'relative',height:'200px'}}><canvas ref={pieRef} role="img" aria-label="Distribuição por grupo"></canvas></div>
                <div className="chart-legend">
                  <span className="legend-item"><span className="legend-dot" style={{background:'#378ADD'}}></span>Essencial</span>
                  <span className="legend-item"><span className="legend-dot" style={{background:'#E24B4A'}}></span>Discricionário</span>
                  <span className="legend-item"><span className="legend-dot" style={{background:'#1D9E75'}}></span>Renda/Invest.</span>
                  {isConj && <span className="legend-item"><span className="legend-dot" style={{background:'#888780'}}></span>Individual</span>}
                </div>
              </div>
            </div>
            {/* Breakdown por responsável na Conjunta */}
            {isConj && (
              <div className="chart-card" style={{marginTop:'1rem'}}>
                <div className="chart-card-header"><span className="chart-card-title">Por responsável</span></div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'1rem',textAlign:'center'}}>
                  {['Ronaldo','Nathália','Casal'].map(r => {
                    const total = data.filter(d=>d.responsavel===r&&d.tipo==='Despesa').reduce((s,d)=>s+d.valor,0)
                    const cls   = r==='Ronaldo'?'resp-ronaldo':r==='Nathália'?'resp-nathalia':'resp-casal'
                    return (
                      <div key={r}>
                        <div style={{marginBottom:'.5rem'}}><span className={`resp-badge ${cls}`}>{r}</span></div>
                        <div style={{fontSize:'1.2rem',fontWeight:600}}>{fmt(total)}</div>
                        <div style={{fontSize:'.75rem',color:'var(--text-muted)'}}>{data.filter(d=>d.responsavel===r).length} registros</div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </>
        )}

        {/* TRANSAÇÕES */}
        {!loading && tab==='transacoes' && (
          <div className="chart-card">
            <div className="chart-card-header">
              <span className="chart-card-title">Todas as transações</span>
              <div style={{display:'flex',gap:'.5rem',flexWrap:'wrap'}}>
                <select className="form-select" style={{width:'auto',padding:'.3rem .6rem',fontSize:'.8rem'}} value={filterTipo} onChange={e=>setFilterTipo(e.target.value)}>
                  <option value="">Todos os tipos</option>
                  <option>Despesa</option><option>Investimento</option><option>Receita</option>
                </select>
                <select className="form-select" style={{width:'auto',padding:'.3rem .6rem',fontSize:'.8rem'}} value={filterCat} onChange={e=>setFilterCat(e.target.value)}>
                  <option value="">Todas as categorias</option>
                  {cats.map(c=><option key={c} value={c}>{c}</option>)}
                </select>
                {isConj && (
                  <select className="form-select" style={{width:'auto',padding:'.3rem .6rem',fontSize:'.8rem'}} value={filterResp} onChange={e=>setFilterResp(e.target.value)}>
                    <option value="">Todos</option>
                    <option>Ronaldo</option><option>Nathália</option><option>Casal</option>
                  </select>
                )}
              </div>
            </div>
            {txData.length ? (
              <table className="tx-table">
                <thead>
                  <tr>
                    <th>Data</th><th>Descrição</th><th>Categoria</th>
                    {isConj && <th>Responsável</th>}
                    <th style={{textAlign:'right'}}>Valor</th>
                  </tr>
                </thead>
                <tbody>
                  {txData.map(d => {
                    const grupo = CAT_GRUPO[d.cat] || 'azul'
                    const cls   = d.tipo==='Receita'?'valor-pos':d.tipo==='Investimento'?'valor-inv':'valor-neg'
                    const sinal = d.tipo==='Receita'?'+':'-'
                    const ds    = d.dataGasto ? new Date(d.dataGasto+'T00:00:00').toLocaleDateString('pt-BR') : d.dataPag ? new Date(d.dataPag+'T00:00:00').toLocaleDateString('pt-BR') : '-'
                    const rCls  = d.responsavel==='Ronaldo'?'resp-ronaldo':d.responsavel==='Nathália'?'resp-nathalia':'resp-casal'
                    return (
                      <tr key={d.id}>
                        <td>{ds}</td>
                        <td style={{fontWeight:500}}>{d.desc||'-'}</td>
                        <td><span className={`cat-badge cat-${grupo}`}>{d.cat||'-'}</span></td>
                        {isConj && <td>{d.responsavel && <span className={`resp-badge ${rCls}`}>{d.responsavel}</span>}</td>}
                        <td style={{textAlign:'right',fontWeight:600}} className={cls}>{sinal}{fmt(d.valor)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            ) : <div className="empty">Nenhuma transação encontrada</div>}
          </div>
        )}

        {/* RECORRENTES - só pessoal */}
        {!loading && tab==='recorrentes' && !isConj && (
          <div className="chart-card">
            <div className="chart-card-header">
              <span className="chart-card-title">Gastos recorrentes</span>
              <span className="chart-card-sub">
                {RECORRENTES_PESSOAL.filter(r=>nomes.some(n=>n.includes(r.nome.toLowerCase().substring(0,10)))).length} lançados · {RECORRENTES_PESSOAL.filter(r=>!nomes.some(n=>n.includes(r.nome.toLowerCase().substring(0,10)))).length} pendentes
              </span>
            </div>
            <div className="rec-grid">
              {RECORRENTES_PESSOAL.map(r => {
                const ok = nomes.some(n => n.includes(r.nome.toLowerCase().substring(0,10)))
                return (
                  <div key={r.nome} className={`rec-item ${ok?'ok':'pending'}`}>
                    <span className={`rec-badge ${ok?'badge-ok':'badge-pending'}`}>{ok?'✓ Lançado':'⚠ Pendente'}</span>
                    <div style={{fontWeight:500,fontSize:'.825rem'}}>{r.nome}</div>
                    <div style={{fontSize:'.7rem',color:'var(--text-muted)'}}>Dia {r.dia} · {r.cat}</div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* RECORRENTES - conjunta: tabela de gastos fixos */}
        {!loading && tab==='recorrentes' && isConj && (
          <div className="chart-card">
            <div className="chart-card-header"><span className="chart-card-title">Gastos fixos do casal</span></div>
            <div style={{fontSize:'.875rem',color:'var(--text-muted)',marginBottom:'1rem'}}>
              Configure aqui os gastos fixos mensais do casal para acompanhar o que foi ou não lançado.
            </div>
            <div className="empty">Em breve — adicione seus gastos fixos conjuntos aqui. <br/>Por enquanto, acompanhe pelas Transações.</div>
          </div>
        )}

        {/* COMPARATIVO */}
        {tab==='comparativo' && (
          <>
            <div className="chart-card">
              <div className="chart-card-header"><span className="chart-card-title">Comparativo entre meses — {label}</span></div>
              {!compareData ? <div className="loading"><div className="spinner"></div> Carregando meses...</div> : (
                <>
                  <div style={{position:'relative',height:'300px'}}><canvas ref={compRef} role="img" aria-label="Comparativo mensal"></canvas></div>
                  <div className="chart-legend">
                    <span className="legend-item"><span className="legend-dot" style={{background:'#1D9E75'}}></span>Entradas</span>
                    <span className="legend-item"><span className="legend-dot" style={{background:'#E24B4A'}}></span>Saídas</span>
                    <span className="legend-item"><span className="legend-dot" style={{background:'#378ADD'}}></span>Investimentos</span>
                  </div>
                </>
              )}
            </div>
            {compareData && (
              <div className="compare-grid">
                {compareData.labels.map((l: string, i: number) => {
                  const s = compareData.entradas[i]-compareData.saidas[i]-compareData.invests[i]
                  return (
                    <div key={l} className="chart-card" style={{padding:'1rem'}}>
                      <div style={{fontWeight:600,marginBottom:'.75rem'}}>{l}</div>
                      <div style={{display:'flex',flexDirection:'column',gap:'.4rem',fontSize:'.8rem'}}>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Entradas</span><span style={{color:'var(--green-dark)',fontWeight:500}}>{fmt(compareData.entradas[i])}</span></div>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Saídas</span><span style={{color:'var(--red)',fontWeight:500}}>{fmt(compareData.saidas[i])}</span></div>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Invest.</span><span style={{color:'var(--blue-dark)',fontWeight:500}}>{fmt(compareData.invests[i])}</span></div>
                        <div style={{borderTop:'1px solid var(--border)',paddingTop:'.4rem',display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Saldo</span><span style={{fontWeight:600,color:s>=0?'var(--green-dark)':'var(--red)'}}>{fmt(s)}</span></div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </>
        )}
      </div>

      {showModal && dbId && (
        <ModalLancamento
          month={month} dbId={dbId} isConj={isConj} cats={CATS}
          accent={accent}
          onClose={() => setShowModal(false)}
          onSaved={() => { setShowModal(false); loadMonth(month) }}
        />
      )}
    </div>
  )
}

function ModalLancamento({ month, dbId, isConj, cats, accent, onClose, onSaved }: any) {
  const [tipo, setTipo]         = useState('Despesa')
  const [desc, setDesc]         = useState('')
  const [valor, setValor]       = useState('')
  const [cat, setCat]           = useState(cats['Despesa'][0])
  const [resp, setResp]         = useState('Casal')
  const [obs, setObs]           = useState('')
  const today = new Date().toISOString().split('T')[0]
  const [dataGasto, setDataGasto] = useState(today)
  const [dataPag, setDataPag]     = useState(today)
  const [saving, setSaving]       = useState(false)

  async function salvar() {
    if (!desc || !valor) return
    setSaving(true)
    await fetch('/api/criar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dbId, isConjunta: isConj, desc, valor: parseFloat(valor), tipo, cat, dataGasto, dataPag, responsavel: resp, observacao: obs })
    })
    setSaving(false)
    onSaved()
  }

  return (
    <div className="modal-overlay active" onClick={e => { if (e.target===e.currentTarget) onClose() }}>
      <div className="modal">
        <div className="modal-title">Novo lançamento — {month}</div>
        <div className="form-group">
          <label className="form-label">Descrição</label>
          <input className="form-input" type="text" placeholder="Ex: Supermercado, Conta de luz..." value={desc} onChange={e=>setDesc(e.target.value)} />
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Valor (R$)</label>
            <input className="form-input" type="number" step="0.01" placeholder="0,00" value={valor} onChange={e=>setValor(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Tipo</label>
            <select className="form-select" value={tipo} onChange={e=>{setTipo(e.target.value);setCat(cats[e.target.value]?.[0]||'')}}>
              <option>Despesa</option><option>Investimento</option><option>Receita</option>
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Categoria</label>
            <select className="form-select" value={cat} onChange={e=>setCat(e.target.value)}>
              {(cats[tipo]||[]).map((c:string)=><option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          {isConj && (
            <div className="form-group">
              <label className="form-label">Responsável</label>
              <select className="form-select" value={resp} onChange={e=>setResp(e.target.value)}>
                <option>Casal</option><option>Ronaldo</option><option>Nathália</option>
              </select>
            </div>
          )}
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Data do gasto</label>
            <input className="form-input" type="date" value={dataGasto} onChange={e=>setDataGasto(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Data pagamento</label>
            <input className="form-input" type="date" value={dataPag} onChange={e=>setDataPag(e.target.value)} />
          </div>
        </div>
        {isConj && (
          <div className="form-group">
            <label className="form-label">Observação (opcional)</label>
            <input className="form-input" type="text" placeholder="Nota adicional..." value={obs} onChange={e=>setObs(e.target.value)} />
          </div>
        )}
        <div className="modal-actions">
          <button className="btn-cancel" onClick={onClose}>Cancelar</button>
          <button className="btn-save" style={{background:accent}} onClick={salvar} disabled={saving}>
            {saving?'Salvando...':'Salvar no Notion'}
          </button>
        </div>
      </div>
    </div>
  )
}
