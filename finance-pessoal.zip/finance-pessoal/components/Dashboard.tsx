'use client'

import { useState, useEffect, useRef } from 'react'
import { Chart, registerables } from 'chart.js'
import { MONTHS, CAT_GRUPO, CAT_COLOR, RECORRENTES, calcResumo, fmt, type Transacao } from '@/lib/notion'

Chart.register(...registerables)

export default function Dashboard() {
  const [month, setMonth] = useState('Fevereiro')
  const [data, setData] = useState<Transacao[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'dashboard'|'transacoes'|'recorrentes'|'comparativo'>('dashboard')
  const [showModal, setShowModal] = useState(false)
  const [filterTipo, setFilterTipo] = useState('')
  const [filterCat, setFilterCat] = useState('')
  const pieRef   = useRef<HTMLCanvasElement>(null)
  const compRef  = useRef<HTMLCanvasElement>(null)
  const pieChart = useRef<Chart|null>(null)
  const compChart= useRef<Chart|null>(null)
  const [compareData, setCompareData] = useState<any>(null)

  async function loadMonth(m = month) {
    setLoading(true)
    try {
      const res = await fetch(`/api/transacoes?month=${encodeURIComponent(m)}`)
      const json = await res.json()
      setData(Array.isArray(json) ? json : [])
    } catch { setData([]) }
    setLoading(false)
  }

  useEffect(() => { loadMonth(month) }, [month])

  useEffect(() => {
    if (activeTab !== 'dashboard' || loading || !pieRef.current) return
    const { saidas } = calcResumo(data)
    const grupTotais = { azul: 0, vermelho: 0, verde: 0 }
    data.filter(d => d.tipo === 'Despesa').forEach(d => {
      const g = CAT_GRUPO[d.cat]
      if (g) grupTotais[g as keyof typeof grupTotais] += d.valor
    })
    if (pieChart.current) pieChart.current.destroy()
    pieChart.current = new Chart(pieRef.current, {
      type: 'doughnut',
      data: {
        labels: ['Essencial','Discricionário','Renda'],
        datasets: [{ data: [grupTotais.azul, grupTotais.vermelho, grupTotais.verde], backgroundColor: ['#378ADD','#E24B4A','#1D9E75'], borderWidth: 0 }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    })
  }, [activeTab, data, loading])

  useEffect(() => {
    if (activeTab !== 'comparativo') return
    loadCompare()
  }, [activeTab])

  async function loadCompare() {
    const labels: string[] = [], entradas: number[] = [], saidas: number[] = [], invests: number[] = []
    for (const m of MONTHS) {
      try {
        const res = await fetch(`/api/transacoes?month=${encodeURIComponent(m)}`)
        const json = await res.json()
        if (!Array.isArray(json) || !json.length) continue
        const r = calcResumo(json)
        labels.push(m.substring(0,3))
        entradas.push(+r.entradas.toFixed(2))
        saidas.push(+r.saidas.toFixed(2))
        invests.push(+r.invest.toFixed(2))
      } catch {}
    }
    setCompareData({ labels, entradas, saidas, invests })
  }

  useEffect(() => {
    if (!compareData || !compRef.current) return
    if (compChart.current) compChart.current.destroy()
    compChart.current = new Chart(compRef.current, {
      type: 'bar',
      data: {
        labels: compareData.labels,
        datasets: [
          { label: 'Entradas',      data: compareData.entradas, backgroundColor: '#1D9E75' },
          { label: 'Saídas',        data: compareData.saidas,   backgroundColor: '#E24B4A' },
          { label: 'Investimentos', data: compareData.invests,  backgroundColor: '#378ADD' },
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { autoSkip: false } },
          y: { ticks: { callback: (v: any) => 'R$' + Number(v/1000).toFixed(0) + 'k' } }
        }
      }
    })
  }, [compareData])

  const { entradas, saidas, invest, saldo } = calcResumo(data)

  const catTotais: Record<string,number> = {}
  data.filter(d => d.tipo === 'Despesa').forEach(d => {
    catTotais[d.cat] = (catTotais[d.cat] || 0) + d.valor
  })
  const maxCat = Math.max(...Object.values(catTotais), 1)

  const cats = [...new Set(data.map(d => d.cat))].filter(Boolean)
  let txData = data
  if (filterTipo) txData = txData.filter(d => d.tipo === filterTipo)
  if (filterCat)  txData = txData.filter(d => d.cat  === filterCat)
  txData = [...txData].sort((a,b) => (b.dataGasto||b.dataPag||'').localeCompare(a.dataGasto||a.dataPag||''))

  const nomes = data.map(d => d.desc.toLowerCase())

  return (
    <div className="app">
      {/* HEADER */}
      <div className="header">
        <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
          <div className="header-logo">💰 <span>Finance</span> <span style={{color:'var(--text-muted)',fontWeight:400,fontSize:'0.75rem'}}>Pessoal</span></div>
          <div className="month-selector">
            <select value={month} onChange={e => setMonth(e.target.value)}>
              {MONTHS.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display:'flex', gap:'0.75rem' }}>
          <button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo lançamento</button>
          <a href="/" className="btn-ghost">← Início</a>
        </div>
      </div>

      <div className="main">
        {/* TABS */}
        <div className="nav-tabs">
          {(['dashboard','transacoes','recorrentes','comparativo'] as const).map(t => (
            <button key={t} className={`nav-tab ${activeTab===t?'active':''}`} onClick={() => setActiveTab(t)}>
              {t === 'dashboard' ? '📊 Dashboard' : t === 'transacoes' ? '📋 Transações' : t === 'recorrentes' ? '🔄 Recorrentes' : '📈 Comparativo'}
            </button>
          ))}
        </div>

        {loading && <div className="loading"><div className="spinner"></div> Carregando {month}...</div>}

        {/* DASHBOARD */}
        {!loading && activeTab === 'dashboard' && (
          <>
            <div className="summary-grid">
              <div className="summary-card"><div className="card-indicator ind-green"></div><div className="label">Entradas</div><div className="value" style={{color:'var(--green-dark)'}}>{fmt(entradas)}</div><div className="sub">{data.filter(d=>d.tipo==='Receita').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-red"></div><div className="label">Saídas</div><div className="value" style={{color:'var(--red)'}}>{fmt(saidas)}</div><div className="sub">{data.filter(d=>d.tipo==='Despesa').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-blue"></div><div className="label">Investimentos</div><div className="value" style={{color:'var(--blue-dark)'}}>{fmt(invest)}</div><div className="sub">{data.filter(d=>d.tipo==='Investimento').length} registros</div></div>
              <div className="summary-card"><div className="card-indicator ind-gray"></div><div className="label">Saldo</div><div className="value" style={{color:saldo>=0?'var(--green-dark)':'var(--red)'}}>{fmt(saldo)}</div><div className="sub">{saldo>=0?'Positivo':'Negativo'}</div></div>
            </div>
            <div className="dashboard-grid">
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Saídas por categoria</span><span className="chart-card-sub">{fmt(saidas)} total</span></div>
                <div className="cat-list">
                  {Object.entries(catTotais).sort((a,b)=>b[1]-a[1]).map(([cat,val]) => (
                    <div key={cat} className="cat-item">
                      <div className="cat-dot" style={{background:CAT_COLOR[cat]||'#888'}}></div>
                      <span className="cat-name">{cat}</span>
                      <div className="cat-bar-wrap"><div className="cat-bar" style={{width:`${(val/maxCat*100).toFixed(0)}%`,background:CAT_COLOR[cat]||'#888'}}></div></div>
                      <span className="cat-value">{fmt(val)}</span>
                    </div>
                  ))}
                  {!Object.keys(catTotais).length && <div className="empty">Nenhuma saída registrada</div>}
                </div>
              </div>
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Distribuição por grupo</span></div>
                <div style={{position:'relative',height:'200px'}}><canvas ref={pieRef} role="img" aria-label="Distribuição por grupo"></canvas></div>
                <div className="chart-legend">
                  <span className="legend-item"><span className="legend-dot" style={{background:'#378ADD'}}></span>Essencial</span>
                  <span className="legend-item"><span className="legend-dot" style={{background:'#E24B4A'}}></span>Discricionário</span>
                  <span className="legend-item"><span className="legend-dot" style={{background:'#1D9E75'}}></span>Renda</span>
                </div>
              </div>
            </div>
          </>
        )}

        {/* TRANSAÇÕES */}
        {!loading && activeTab === 'transacoes' && (
          <div className="chart-card">
            <div className="chart-card-header">
              <span className="chart-card-title">Todas as transações</span>
              <div style={{display:'flex',gap:'0.5rem'}}>
                <select className="form-select" style={{width:'auto',padding:'0.3rem 0.6rem',fontSize:'0.8rem'}} value={filterTipo} onChange={e=>{setFilterTipo(e.target.value);setFilterCat('')}}>
                  <option value="">Todos os tipos</option>
                  <option value="Despesa">Despesa</option>
                  <option value="Investimento">Investimento</option>
                  <option value="Receita">Receita</option>
                </select>
                <select className="form-select" style={{width:'auto',padding:'0.3rem 0.6rem',fontSize:'0.8rem'}} value={filterCat} onChange={e=>setFilterCat(e.target.value)}>
                  <option value="">Todas as categorias</option>
                  {cats.map(c=><option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            {txData.length ? (
              <table className="tx-table">
                <thead><tr><th>Data</th><th>Descrição</th><th>Categoria</th><th style={{textAlign:'right'}}>Valor</th></tr></thead>
                <tbody>
                  {txData.map(d => {
                    const grupo = CAT_GRUPO[d.cat] || 'azul'
                    const cls   = d.tipo==='Receita'?'valor-pos':d.tipo==='Investimento'?'valor-inv':'valor-neg'
                    const sinal = d.tipo==='Receita'?'+':'-'
                    const ds    = d.dataGasto ? new Date(d.dataGasto+'T00:00:00').toLocaleDateString('pt-BR') : d.dataPag ? new Date(d.dataPag+'T00:00:00').toLocaleDateString('pt-BR') : '-'
                    return (
                      <tr key={d.id}>
                        <td>{ds}</td>
                        <td style={{fontWeight:500}}>{d.desc||'-'}</td>
                        <td><span className={`cat-badge cat-${grupo}`}>{d.cat||'-'}</span></td>
                        <td style={{textAlign:'right',fontWeight:600}} className={cls}>{sinal}{fmt(d.valor)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            ) : <div className="empty">Nenhuma transação encontrada</div>}
          </div>
        )}

        {/* RECORRENTES */}
        {!loading && activeTab === 'recorrentes' && (
          <div className="chart-card">
            <div className="chart-card-header">
              <span className="chart-card-title">Gastos recorrentes</span>
              <span className="chart-card-sub">
                {RECORRENTES.filter(r=>nomes.some(n=>n.includes(r.nome.toLowerCase().substring(0,10)))).length} lançados · {RECORRENTES.filter(r=>!nomes.some(n=>n.includes(r.nome.toLowerCase().substring(0,10)))).length} pendentes
              </span>
            </div>
            <div className="rec-grid">
              {RECORRENTES.map(r => {
                const ok = nomes.some(n => n.includes(r.nome.toLowerCase().substring(0,10)))
                return (
                  <div key={r.nome} className={`rec-item ${ok?'ok':'pending'}`}>
                    <span className={`rec-badge ${ok?'badge-ok':'badge-pending'}`}>{ok?'✓ Lançado':'⚠ Pendente'}</span>
                    <div style={{fontWeight:500,fontSize:'0.825rem'}}>{r.nome}</div>
                    <div style={{fontSize:'0.7rem',color:'var(--text-muted)'}}>Todo dia {r.dia} · {r.cat}</div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* COMPARATIVO */}
        {activeTab === 'comparativo' && (
          <>
            <div className="chart-card">
              <div className="chart-card-header"><span className="chart-card-title">Comparativo entre meses</span></div>
              {!compareData ? <div className="loading"><div className="spinner"></div> Carregando meses...</div> : (
                <>
                  <div style={{position:'relative',height:'300px'}}><canvas ref={compRef} role="img" aria-label="Comparativo mensal"></canvas></div>
                  <div className="chart-legend">
                    <span className="legend-item"><span className="legend-dot" style={{background:'#1D9E75'}}></span>Entradas</span>
                    <span className="legend-item"><span className="legend-dot" style={{background:'#E24B4A'}}></span>Saídas</span>
                    <span className="legend-item"><span className="legend-dot" style={{background:'#378ADD'}}></span>Investimentos</span>
                  </div>
                </>
              )}
            </div>
            {compareData && (
              <div className="compare-grid">
                {compareData.labels.map((l: string, i: number) => {
                  const s = compareData.entradas[i] - compareData.saidas[i] - compareData.invests[i]
                  return (
                    <div key={l} className="chart-card" style={{padding:'1rem'}}>
                      <div style={{fontWeight:600,marginBottom:'0.75rem'}}>{l}</div>
                      <div style={{display:'flex',flexDirection:'column',gap:'0.4rem',fontSize:'0.8rem'}}>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Entradas</span><span style={{color:'var(--green-dark)',fontWeight:500}}>{fmt(compareData.entradas[i])}</span></div>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Saídas</span><span style={{color:'var(--red)',fontWeight:500}}>{fmt(compareData.saidas[i])}</span></div>
                        <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Invest.</span><span style={{color:'var(--blue-dark)',fontWeight:500}}>{fmt(compareData.invests[i])}</span></div>
                        <div style={{borderTop:'1px solid var(--border)',paddingTop:'0.4rem',display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--text-muted)'}}>Saldo</span><span style={{fontWeight:600,color:s>=0?'var(--green-dark)':'var(--red)'}}>{fmt(s)}</span></div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </>
        )}
      </div>

      {/* MODAL */}
      {showModal && <ModalLancamento month={month} onClose={() => setShowModal(false)} onSaved={() => { setShowModal(false); loadMonth(month) }} />}
    </div>
  )
}

function ModalLancamento({ month, onClose, onSaved }: { month: string; onClose: () => void; onSaved: () => void }) {
  const CATS: Record<string,string[]> = {
    Despesa:     ['Alimentação','Saúde','Transporte','Moradia','Gasto Superflúo','Viagem','Lazer'],
    Investimento:['Investimento','Saúde'],
    Receita:     ['Pró Labore','Distribuição Lucros','Outras Rendas'],
  }
  const [tipo, setTipo] = useState('Despesa')
  const [desc, setDesc] = useState('')
  const [valor, setValor] = useState('')
  const [cat, setCat] = useState('Alimentação')
  const today = new Date().toISOString().split('T')[0]
  const [dataGasto, setDataGasto] = useState(today)
  const [dataPag,   setDataPag]   = useState(today)
  const [saving, setSaving] = useState(false)

  async function salvar() {
    if (!desc || !valor) return
    setSaving(true)
    await fetch('/api/criar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ month, desc, valor: parseFloat(valor), tipo, cat, dataGasto, dataPag })
    })
    setSaving(false)
    onSaved()
  }

  return (
    <div className="modal-overlay active" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal">
        <div className="modal-title">Novo lançamento — {month}</div>
        <div className="form-group">
          <label className="form-label">Descrição</label>
          <input className="form-input" type="text" placeholder="Ex: Almoço, Gasolina..." value={desc} onChange={e=>setDesc(e.target.value)} />
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Valor (R$)</label>
            <input className="form-input" type="number" step="0.01" placeholder="0,00" value={valor} onChange={e=>setValor(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Tipo</label>
            <select className="form-select" value={tipo} onChange={e=>{setTipo(e.target.value);setCat(CATS[e.target.value][0])}}>
              <option value="Despesa">Despesa</option>
              <option value="Investimento">Investimento</option>
              <option value="Receita">Receita</option>
            </select>
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Categoria</label>
          <select className="form-select" value={cat} onChange={e=>setCat(e.target.value)}>
            {(CATS[tipo]||[]).map(c=><option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Data do gasto</label>
            <input className="form-input" type="date" value={dataGasto} onChange={e=>setDataGasto(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Data pagamento</label>
            <input className="form-input" type="date" value={dataPag} onChange={e=>setDataPag(e.target.value)} />
          </div>
        </div>
        <div className="modal-actions">
          <button className="btn-cancel" onClick={onClose}>Cancelar</button>
          <button className="btn-save" onClick={salvar} disabled={saving}>{saving?'Salvando...':'Salvar no Notion'}</button>
        </div>
      </div>
    </div>
  )
}
