import { NextRequest, NextResponse } from 'next/server'
import { findMonthDB, PESSOAL_2026_PAGE_ID, CONJUNTA_2026_PAGE_ID } from '@/lib/notion'

export async function GET(req: NextRequest) {
  const month  = req.nextUrl.searchParams.get('month') || ''
  const perfil = req.nextUrl.searchParams.get('perfil') || 'pessoal'
  const pageId = perfil === 'conjunta' ? CONJUNTA_2026_PAGE_ID : PESSOAL_2026_PAGE_ID

  try {
    const dbId = await findMonthDB(pageId, month)
    if (!dbId) return NextResponse.json({ error: 'Mês não encontrado' }, { status: 404 })
    return NextResponse.json({ dbId })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
