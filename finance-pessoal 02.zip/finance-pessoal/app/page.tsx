import Link from 'next/link'

export default function Home() {
  return (
    <div className="home-screen">
      <div className="home-card">
        <div style={{ fontSize:'2.5rem', marginBottom:'.75rem' }}>💰</div>
        <h1 className="home-title">Finance Dashboard</h1>
        <p className="home-sub">Selecione o perfil para acessar</p>
        <div className="profile-grid">
          <Link href="/pessoal" className="profile-card">
            <span className="profile-icon">👤</span>
            <span className="profile-name">Pessoal</span>
            <span className="profile-desc">Suas finanças pessoais</span>
          </Link>
          <Link href="/conjunta" className="profile-card">
            <span className="profile-icon">👫</span>
            <span className="profile-name">Conta Conjunta</span>
            <span className="profile-desc">Você + Nathália</span>
          </Link>
          <Link href="/metas" className="profile-card">
            <span className="profile-icon">🎯</span>
            <span className="profile-name">Metas</span>
            <span className="profile-desc">Planejamento anual</span>
          </Link>
          <Link href="/relatorios" className="profile-card">
            <span className="profile-icon">📊</span>
            <span className="profile-name">Relatórios</span>
            <span className="profile-desc">Visão anual completa</span>
          </Link>
        </div>
        <p style={{ fontSize:'.75rem', color:'var(--text-light)' }}>
          Dados sincronizados em tempo real com o Notion
        </p>
      </div>
    </div>
  )
}
