import { NextRequest, NextResponse } from 'next/server'
import { criarTransacao } from '@/lib/notion'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { dbId, isConjunta, ...dados } = body
  if (!dbId) return NextResponse.json({ error: 'dbId obrigatório' }, { status: 400 })
  try {
    await criarTransacao(dbId, dados, isConjunta)
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
