// lib/notion.ts — busca automática por nome do mês

export const NOTION_TOKEN = process.env.NOTION_TOKEN || ''

// IDs fixos das páginas pai (não mudam nunca)
export const PESSOAL_2026_PAGE_ID = '36f74c88-0981-811d-be79-cc3ba42721fe'
export const CONJUNTA_2026_PAGE_ID = '36f74c88-0981-8174-970d-e659aa2e45ef'

export const MONTHS = [
  'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
  'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'
]

export interface Transacao {
  id: string
  desc: string
  valor: number
  tipo: string
  cat: string
  dataGasto: string
  dataPag: string
  responsavel?: string
  observacao?: string
}

export const CATS_PESSOAL: Record<string, string[]> = {
  Despesa:      ['Alimentação','Saúde','Transporte','Moradia','Gasto Superflúo','Viagem','Lazer'],
  Investimento: ['Investimento','Saúde'],
  Receita:      ['Pró Labore','Distribuição Lucros','Outras Rendas'],
}

export const CATS_CONJUNTA: Record<string, string[]> = {
  Despesa: [
    'Moradia','Contas da Casa','Mercado e Alimentação','Alimentação Fora',
    'Transporte','Saúde','Educação e Desenvolvimento','Lazer e Viagens',
    'Compras Pessoais','Casa e Decoração','Assinaturas','Família e Presentes',
    'Pets','Dívidas e Parcelas','Imprevistos',
    'Gastos Individuais Dele','Gastos Individuais Dela',
  ],
  Investimento: ['Investimentos','Objetivos do Casal'],
  Receita: ['Outras Rendas'],
}

export const CAT_GRUPO_PESSOAL: Record<string, string> = {
  'Pró Labore':'verde','Distribuição Lucros':'verde','Outras Rendas':'verde',
  'Investimento':'azul','Alimentação':'azul','Saúde':'azul','Transporte':'azul','Moradia':'azul',
  'Gasto Superflúo':'vermelho','Viagem':'vermelho','Lazer':'vermelho',
}

export const CAT_GRUPO_CONJUNTA: Record<string, string> = {
  'Moradia':'azul','Contas da Casa':'azul','Mercado e Alimentação':'azul',
  'Alimentação Fora':'azul','Transporte':'azul','Saúde':'azul','Educação e Desenvolvimento':'azul',
  'Lazer e Viagens':'vermelho','Compras Pessoais':'vermelho','Casa e Decoração':'vermelho',
  'Assinaturas':'vermelho','Família e Presentes':'vermelho','Pets':'vermelho',
  'Dívidas e Parcelas':'vermelho','Imprevistos':'vermelho',
  'Gastos Individuais Dele':'cinza','Gastos Individuais Dela':'cinza',
  'Investimentos':'verde','Objetivos do Casal':'verde','Outras Rendas':'verde',
}

export const CAT_COLOR: Record<string, string> = {
  'Alimentação':'#378ADD','Saúde':'#1D9E75','Transporte':'#BA7517','Moradia':'#533AB7',
  'Gasto Superflúo':'#E24B4A','Viagem':'#D4537E','Lazer':'#D85A30',
  'Pró Labore':'#1D9E75','Distribuição Lucros':'#0F6E56','Outras Rendas':'#085041',
  'Investimento':'#185FA5','Contas da Casa':'#533AB7','Mercado e Alimentação':'#378ADD',
  'Alimentação Fora':'#3A9BD5','Educação e Desenvolvimento':'#BA7517',
  'Lazer e Viagens':'#D4537E','Compras Pessoais':'#E24B4A','Casa e Decoração':'#D85A30',
  'Assinaturas':'#9B59B6','Família e Presentes':'#E67E22','Pets':'#27AE60',
  'Dívidas e Parcelas':'#C0392B','Imprevistos':'#7F8C8D',
  'Gastos Individuais Dele':'#2980B9','Gastos Individuais Dela':'#8E44AD',
  'Investimentos':'#1D9E75','Objetivos do Casal':'#0F6E56',
}

export const RECORRENTES_PESSOAL = [
  { nome: 'Plano Crossfit Big Box',        dia: 1,  cat: 'Saúde'           },
  { nome: 'Seguro Icatu',                  dia: 5,  cat: 'Saúde'           },
  { nome: 'Consórcio Igreja',              dia: 10, cat: 'Investimento'    },
  { nome: 'Consórcio Família',             dia: 10, cat: 'Investimento'    },
  { nome: 'Parcela Financiamento AP Mauá', dia: 7,  cat: 'Moradia'         },
  { nome: 'Condomínio Mauá',               dia: 15, cat: 'Moradia'         },
  { nome: 'Seguro Mauá',                   dia: 20, cat: 'Moradia'         },
  { nome: 'Assinatura Spotify',            dia: 1,  cat: 'Lazer'           },
  { nome: 'Assinatura iCloud',             dia: 1,  cat: 'Lazer'           },
  { nome: 'Plano Internet TIM',            dia: 17, cat: 'Gasto Superflúo' },
]

const headers = () => ({
  'Authorization': `Bearer ${NOTION_TOKEN}`,
  'Notion-Version': '2022-06-28',
  'Content-Type': 'application/json',
})

// Busca automática: encontra o database do mês pelo nome dentro da página 2026
export async function findMonthDB(parentPageId: string, monthName: string): Promise<string | null> {
  const res = await fetch(`https://api.notion.com/v1/blocks/${parentPageId}/children?page_size=50`, {
    headers: headers(),
    cache: 'no-store',
  })
  if (!res.ok) return null
  const data = await res.json()
  for (const block of data.results || []) {
    if (block.type === 'child_database') {
      const title: string = block.child_database?.title || ''
      // Remove emojis e espaços para comparar apenas o nome do mês
      const clean = title.replace(/[\u{1F300}-\u{1FFFF}]|[\u{2600}-\u{26FF}]|\s/gu, '').toLowerCase()
      if (clean.includes(monthName.toLowerCase())) {
        return block.id
      }
    }
  }
  return null
}

function parsePage(p: any, isConjunta = false): Transacao {
  const props = p.properties
  return {
    id:          p.id,
    desc:        props['Descrição']?.title?.[0]?.plain_text || '',
    valor:       props['Valor']?.number || 0,
    tipo:        props['Tipo']?.select?.name || '',
    cat:         props['Categoria']?.select?.name || '',
    dataGasto:   isConjunta
                   ? props['Data Gasto']?.date?.start || ''
                   : props['Data Gasto ']?.date?.start || props['Data']?.date?.start || '',
    dataPag:     props['Data Pagamento']?.date?.start || '',
    responsavel: props['Responsável']?.select?.name || undefined,
    observacao:  props['Observação']?.rich_text?.[0]?.plain_text || undefined,
  }
}

export async function getTransacoes(dbId: string, isConjunta = false): Promise<Transacao[]> {
  if (!NOTION_TOKEN || !dbId) return []
  const res = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ page_size: 100 }),
    cache: 'no-store',
  })
  if (!res.ok) return []
  const data = await res.json()
  return (data.results || []).map((p: any) => parsePage(p, isConjunta))
}

export async function criarTransacao(dbId: string, dados: any, isConjunta = false): Promise<void> {
  const properties: any = {
    'Descrição': { title: [{ text: { content: dados.desc } }] },
    'Valor':     { number: dados.valor },
    'Tipo':      { select: { name: dados.tipo } },
    'Categoria': { select: { name: dados.cat } },
  }
  if (dados.dataGasto) {
    properties[isConjunta ? 'Data Gasto' : 'Data Gasto '] = { date: { start: dados.dataGasto } }
  }
  if (dados.dataPag) {
    properties['Data Pagamento'] = { date: { start: dados.dataPag } }
  }
  if (isConjunta && dados.responsavel) {
    properties['Responsável'] = { select: { name: dados.responsavel } }
  }
  if (isConjunta && dados.observacao) {
    properties['Observação'] = { rich_text: [{ text: { content: dados.observacao } }] }
  }

  const res = await fetch('https://api.notion.com/v1/pages', {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ parent: { database_id: dbId }, properties }),
  })
  if (!res.ok) throw new Error(`Erro ${res.status}`)
}

export function calcResumo(data: Transacao[]) {
  const entradas = data.filter(d => d.tipo === 'Receita').reduce((s, d) => s + d.valor, 0)
  const saidas   = data.filter(d => d.tipo === 'Despesa').reduce((s, d) => s + d.valor, 0)
  const invest   = data.filter(d => d.tipo === 'Investimento').reduce((s, d) => s + d.valor, 0)
  return { entradas, saidas, invest, saldo: entradas - saidas - invest }
}

export function fmt(v: number): string {
  return 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
