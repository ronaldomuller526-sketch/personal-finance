import { NextRequest, NextResponse } from 'next/server'
import { getTransacoes } from '@/lib/notion'

export async function GET(req: NextRequest) {
  const dbId      = req.nextUrl.searchParams.get('dbId') || ''
  const isConj    = req.nextUrl.searchParams.get('perfil') === 'conjunta'
  if (!dbId) return NextResponse.json({ error: 'dbId obrigatório' }, { status: 400 })
  try {
    const data = await getTransacoes(dbId, isConj)
    return NextResponse.json(data)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
