import { NextRequest, NextResponse } from 'next/server'
import { getTransacoes, MONTH_IDS } from '@/lib/notion'

export async function GET(req: NextRequest) {
  const month = req.nextUrl.searchParams.get('month') || 'Fevereiro'
  const dbId  = MONTH_IDS[month]

  if (!dbId) {
    return NextResponse.json({ error: 'Mês inválido' }, { status: 400 })
  }

  try {
    const data = await getTransacoes(dbId)
    return NextResponse.json(data)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
