'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { MONTHS, calcResumo, fmt, CAT_COLOR, type Transacao } from '@/lib/notion'

export default function RelatoriosPage() {
  const [dados, setDados]   = useState<Record<string,any>>({})
  const [dadosC, setDadosC] = useState<Record<string,any>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const pessoal: Record<string,any> = {}
      const conjunta: Record<string,any> = {}
      for (const m of MONTHS) {
        for (const [perfil, store] of [['pessoal', pessoal], ['conjunta', conjunta]] as const) {
          try {
            const r1  = await fetch(`/api/meses?month=${encodeURIComponent(m)}&perfil=${perfil}`)
            const j1  = await r1.json()
            if (!j1.dbId) continue
            const r2  = await fetch(`/api/transacoes?dbId=${j1.dbId}&perfil=${perfil}`)
            const json: Transacao[] = await r2.json()
            if (Array.isArray(json) && json.length) store[m] = { ...calcResumo(json), data: json }
          } catch {}
        }
      }
      setDados(pessoal); setDadosC(conjunta); setLoading(false)
    }
    load()
  }, [])

  function renderTabela(d: Record<string,any>, label: string, accent: string) {
    const meses = MONTHS.filter(m => d[m])
    const totE = meses.reduce((s,m)=>s+d[m].entradas,0)
    const totS = meses.reduce((s,m)=>s+d[m].saidas,0)
    const totI = meses.reduce((s,m)=>s+d[m].invest,0)
    const totSaldo = totE-totS-totI
    const catTotais: Record<string,number> = {}
    meses.forEach(m => d[m].data?.filter((t:Transacao)=>t.tipo==='Despesa').forEach((t:Transacao)=>{ catTotais[t.cat]=(catTotais[t.cat]||0)+t.valor }))
    const top5 = Object.entries(catTotais).sort((a,b)=>b[1]-a[1]).slice(0,5)
    const maxC = Math.max(...top5.map(c=>c[1]),1)

    return (
      <div>
        <h3 style={{fontSize:'1rem',fontWeight:600,marginBottom:'1rem',color:accent}}>{label}</h3>
        <div className="summary-grid" style={{marginBottom:'1.5rem'}}>
          <div className="summary-card"><div className="card-indicator" style={{background:accent}}></div><div className="label">Entradas</div><div className="value" style={{color:'var(--green-dark)'}}>{fmt(totE)}</div><div className="sub">{meses.length} meses</div></div>
          <div className="summary-card"><div className="card-indicator ind-red"></div><div className="label">Saídas</div><div className="value" style={{color:'var(--red)'}}>{fmt(totS)}</div><div className="sub">Média {fmt(totS/(meses.length||1))}/mês</div></div>
          <div className="summary-card"><div className="card-indicator ind-blue"></div><div className="label">Investido</div><div className="value" style={{color:'var(--blue-dark)'}}>{fmt(totI)}</div></div>
          <div className="summary-card"><div className="card-indicator ind-gray"></div><div className="label">Saldo</div><div className="value" style={{color:totSaldo>=0?'var(--green-dark)':'var(--red)'}}>{fmt(totSaldo)}</div></div>
        </div>
        <div className="dashboard-grid">
          <div className="chart-card">
            <div className="chart-card-header"><span className="chart-card-title">Mês a mês</span></div>
            <table className="tx-table">
              <thead><tr><th>Mês</th><th style={{textAlign:'right'}}>Entradas</th><th style={{textAlign:'right'}}>Saídas</th><th style={{textAlign:'right'}}>Saldo</th></tr></thead>
              <tbody>
                {meses.map(m => { const s=d[m].saldo; return (
                  <tr key={m}><td style={{fontWeight:500}}>{m}</td><td style={{textAlign:'right',color:'var(--green-dark)',fontWeight:500}}>{fmt(d[m].entradas)}</td><td style={{textAlign:'right',color:'var(--red)',fontWeight:500}}>{fmt(d[m].saidas)}</td><td style={{textAlign:'right',fontWeight:600,color:s>=0?'var(--green-dark)':'var(--red)'}}>{fmt(s)}</td></tr>
                )})}
              </tbody>
            </table>
          </div>
          <div className="chart-card">
            <div className="chart-card-header"><span className="chart-card-title">Top categorias de gasto</span></div>
            <div className="cat-list">
              {top5.map(([cat,val]) => (
                <div key={cat} className="cat-item">
                  <div className="cat-dot" style={{background:CAT_COLOR[cat]||'#888'}}></div>
                  <span className="cat-name">{cat}</span>
                  <div className="cat-bar-wrap"><div className="cat-bar" style={{width:`${(val/maxC*100).toFixed(0)}%`,background:CAT_COLOR[cat]||'#888'}}></div></div>
                  <span className="cat-value">{fmt(val)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{minHeight:'100vh'}}>
      <div className="header">
        <div className="header-logo">💰 <span>Relatórios 2026</span></div>
        <Link href="/" className="btn-ghost">← Início</Link>
      </div>
      <div className="main">
        {loading ? (
          <div className="loading"><div className="spinner"></div> Carregando todos os meses...</div>
        ) : (
          <div style={{display:'flex',flexDirection:'column',gap:'2.5rem'}}>
            {renderTabela(dados,'👤 Pessoal','var(--green)')}
            {renderTabela(dadosC,'👫 Conjunta','var(--purple)')}
          </div>
        )}
      </div>
    </div>
  )
}
