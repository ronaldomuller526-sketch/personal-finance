// lib/notion.ts
// Integração central com a API do Notion

export const MONTH_IDS: Record<string, string> = {
  Janeiro:  process.env.NOTION_JANEIRO  || '',
  Fevereiro:process.env.NOTION_FEVEREIRO|| '',
  Março:    process.env.NOTION_MARCO    || '',
  Abril:    process.env.NOTION_ABRIL    || '',
  Maio:     process.env.NOTION_MAIO     || '',
  Junho:    process.env.NOTION_JUNHO    || '',
  Julho:    process.env.NOTION_JULHO    || '',
  Agosto:   process.env.NOTION_AGOSTO  || '',
  Setembro: process.env.NOTION_SETEMBRO || '',
  Outubro:  process.env.NOTION_OUTUBRO  || '',
  Novembro: process.env.NOTION_NOVEMBRO || '',
  Dezembro: process.env.NOTION_DEZEMBRO || '',
}

export const MONTHS = Object.keys(MONTH_IDS)

export interface Transacao {
  id: string
  desc: string
  valor: number
  tipo: 'Despesa' | 'Receita' | 'Investimento'
  cat: string
  dataGasto: string
  dataPag: string
}

export const CATEGORIAS = {
  Despesa:     ['Alimentação','Saúde','Transporte','Moradia','Gasto Superflúo','Viagem','Lazer'],
  Investimento:['Investimento','Saúde'],
  Receita:     ['Pró Labore','Distribuição Lucros','Outras Rendas'],
}

export const CAT_GRUPO: Record<string, 'verde' | 'azul' | 'vermelho'> = {
  'Pró Labore':         'verde',
  'Distribuição Lucros':'verde',
  'Outras Rendas':      'verde',
  'Investimento':       'azul',
  'Alimentação':        'azul',
  'Saúde':              'azul',
  'Transporte':         'azul',
  'Moradia':            'azul',
  'Gasto Superflúo':    'vermelho',
  'Viagem':             'vermelho',
  'Lazer':              'vermelho',
}

export const CAT_COLOR: Record<string, string> = {
  'Alimentação':        '#378ADD',
  'Saúde':              '#1D9E75',
  'Transporte':         '#BA7517',
  'Moradia':            '#533AB7',
  'Gasto Superflúo':    '#E24B4A',
  'Viagem':             '#D4537E',
  'Lazer':              '#D85A30',
  'Pró Labore':         '#1D9E75',
  'Distribuição Lucros':'#0F6E56',
  'Outras Rendas':      '#085041',
  'Investimento':       '#185FA5',
}

export const RECORRENTES = [
  { nome: 'Plano Crossfit Big Box',       dia: 1,  cat: 'Saúde'          },
  { nome: 'Seguro Icatu',                 dia: 5,  cat: 'Saúde'          },
  { nome: 'Consórcio Igreja',             dia: 10, cat: 'Investimento'   },
  { nome: 'Consórcio Família',            dia: 10, cat: 'Investimento'   },
  { nome: 'Parcela Financiamento AP Mauá',dia: 7,  cat: 'Moradia'        },
  { nome: 'Condomínio Mauá',              dia: 15, cat: 'Moradia'        },
  { nome: 'Seguro Mauá',                  dia: 20, cat: 'Moradia'        },
  { nome: 'Assinatura Spotify',           dia: 1,  cat: 'Lazer'          },
  { nome: 'Assinatura iCloud',            dia: 1,  cat: 'Lazer'          },
  { nome: 'Plano Internet TIM',           dia: 17, cat: 'Gasto Superflúo'},
]

function parsePage(p: any): Transacao {
  const props = p.properties
  return {
    id:        p.id,
    desc:      props['Descrição']?.title?.[0]?.plain_text || '',
    valor:     props['Valor']?.number || 0,
    tipo:      props['Tipo']?.select?.name || '',
    cat:       props['Categoria']?.select?.name || '',
    dataGasto: props['Data Gasto ']?.date?.start || props['Data']?.date?.start || '',
    dataPag:   props['Data Pagamento']?.date?.start || '',
  }
}

export async function getTransacoes(dbId: string): Promise<Transacao[]> {
  const token = process.env.NOTION_TOKEN
  if (!token || !dbId) return []

  const res = await fetch(`https://api.notion.com/v1/databases/${dbId}/query`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': '2022-06-28',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ page_size: 100 }),
    cache: 'no-store',
  })

  if (!res.ok) throw new Error(`Notion API error: ${res.status}`)
  const data = await res.json()
  return (data.results || []).map(parsePage)
}

export async function criarTransacao(
  dbId: string,
  dados: Omit<Transacao, 'id'>
): Promise<void> {
  const token = process.env.NOTION_TOKEN
  if (!token || !dbId) throw new Error('Token ou database não configurados')

  const properties: any = {
    'Descrição': { title: [{ text: { content: dados.desc } }] },
    'Valor':     { number: dados.valor },
    'Tipo':      { select: { name: dados.tipo } },
    'Categoria': { select: { name: dados.cat } },
  }
  if (dados.dataGasto) properties['Data Gasto '] = { date: { start: dados.dataGasto } }
  if (dados.dataPag)   properties['Data Pagamento'] = { date: { start: dados.dataPag } }

  const res = await fetch('https://api.notion.com/v1/pages', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Notion-Version': '2022-06-28',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ parent: { database_id: dbId }, properties }),
  })

  if (!res.ok) throw new Error(`Erro ao criar página: ${res.status}`)
}

export function calcResumo(data: Transacao[]) {
  const entradas  = data.filter(d => d.tipo === 'Receita').reduce((s, d) => s + d.valor, 0)
  const saidas    = data.filter(d => d.tipo === 'Despesa').reduce((s, d) => s + d.valor, 0)
  const invest    = data.filter(d => d.tipo === 'Investimento').reduce((s, d) => s + d.valor, 0)
  const saldo     = entradas - saidas - invest
  return { entradas, saidas, invest, saldo }
}

export function fmt(v: number): string {
  return 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}
