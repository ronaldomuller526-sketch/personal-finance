import { NextRequest, NextResponse } from 'next/server'
import { criarTransacao, MONTH_IDS } from '@/lib/notion'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { month, ...dados } = body
  const dbId = MONTH_IDS[month]

  if (!dbId) {
    return NextResponse.json({ error: 'Mês inválido' }, { status: 400 })
  }

  try {
    await criarTransacao(dbId, dados)
    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
