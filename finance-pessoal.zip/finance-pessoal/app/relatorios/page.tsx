'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { MONTHS, calcResumo, fmt, type Transacao } from '@/lib/notion'

export default function RelatoriosPage() {
  const [dados, setDados] = useState<Record<string,any>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const result: Record<string,any> = {}
      for (const m of MONTHS) {
        try {
          const res = await fetch(`/api/transacoes?month=${encodeURIComponent(m)}`)
          const json: Transacao[] = await res.json()
          if (Array.isArray(json) && json.length) {
            result[m] = { ...calcResumo(json), count: json.length, data: json }
          }
        } catch {}
      }
      setDados(result)
      setLoading(false)
    }
    load()
  }, [])

  const mesesComDados = MONTHS.filter(m => dados[m])
  const totalEntradas = mesesComDados.reduce((s,m) => s + dados[m].entradas, 0)
  const totalSaidas   = mesesComDados.reduce((s,m) => s + dados[m].saidas,   0)
  const totalInvest   = mesesComDados.reduce((s,m) => s + dados[m].invest,   0)
  const totalSaldo    = totalEntradas - totalSaidas - totalInvest

  // Top categorias do ano
  const catTotais: Record<string,number> = {}
  mesesComDados.forEach(m => {
    dados[m].data?.filter((d:Transacao) => d.tipo==='Despesa').forEach((d:Transacao) => {
      catTotais[d.cat] = (catTotais[d.cat]||0) + d.valor
    })
  })
  const topCats = Object.entries(catTotais).sort((a,b)=>b[1]-a[1]).slice(0,5)
  const maxCat = Math.max(...topCats.map(c=>c[1]),1)

  return (
    <div className="app">
      <div className="header">
        <div className="header-logo">💰 <span>Finance</span> <span style={{color:'var(--text-muted)',fontWeight:400,fontSize:'0.75rem'}}>Relatórios 2026</span></div>
        <Link href="/" className="btn-ghost">← Início</Link>
      </div>

      <div className="main">
        {loading ? (
          <div className="loading"><div className="spinner"></div> Carregando todos os meses...</div>
        ) : (
          <>
            {/* RESUMO ANUAL */}
            <div className="summary-grid" style={{ marginBottom:'1.5rem' }}>
              <div className="summary-card"><div className="card-indicator ind-green"></div><div className="label">Total Entradas</div><div className="value" style={{color:'var(--green-dark)'}}>{fmt(totalEntradas)}</div><div className="sub">{mesesComDados.length} meses registrados</div></div>
              <div className="summary-card"><div className="card-indicator ind-red"></div><div className="label">Total Saídas</div><div className="value" style={{color:'var(--red)'}}>{fmt(totalSaidas)}</div><div className="sub">Média: {fmt(totalSaidas/(mesesComDados.length||1))}/mês</div></div>
              <div className="summary-card"><div className="card-indicator ind-blue"></div><div className="label">Total Investido</div><div className="value" style={{color:'var(--blue-dark)'}}>{fmt(totalInvest)}</div><div className="sub">Média: {fmt(totalInvest/(mesesComDados.length||1))}/mês</div></div>
              <div className="summary-card"><div className="card-indicator ind-gray"></div><div className="label">Saldo Acumulado</div><div className="value" style={{color:totalSaldo>=0?'var(--green-dark)':'var(--red)'}}>{fmt(totalSaldo)}</div><div className="sub">{totalSaldo>=0?'Positivo':'Negativo'}</div></div>
            </div>

            <div className="dashboard-grid">
              {/* MÊS A MÊS */}
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Mês a mês</span></div>
                <table className="tx-table">
                  <thead><tr><th>Mês</th><th style={{textAlign:'right'}}>Entradas</th><th style={{textAlign:'right'}}>Saídas</th><th style={{textAlign:'right'}}>Saldo</th></tr></thead>
                  <tbody>
                    {mesesComDados.map(m => {
                      const s = dados[m].saldo
                      return (
                        <tr key={m}>
                          <td style={{fontWeight:500}}>{m}</td>
                          <td style={{textAlign:'right',color:'var(--green-dark)',fontWeight:500}}>{fmt(dados[m].entradas)}</td>
                          <td style={{textAlign:'right',color:'var(--red)',fontWeight:500}}>{fmt(dados[m].saidas)}</td>
                          <td style={{textAlign:'right',fontWeight:600,color:s>=0?'var(--green-dark)':'var(--red)'}}>{fmt(s)}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>

              {/* TOP CATEGORIAS */}
              <div className="chart-card">
                <div className="chart-card-header"><span className="chart-card-title">Top categorias de gasto no ano</span></div>
                <div className="cat-list">
                  {topCats.map(([cat,val]) => (
                    <div key={cat} className="cat-item">
                      <div className="cat-name" style={{fontWeight:500}}>{cat}</div>
                      <div className="cat-bar-wrap"><div className="cat-bar" style={{width:`${(val/maxCat*100).toFixed(0)}%`,background:'var(--red)'}}></div></div>
                      <span className="cat-value">{fmt(val)}</span>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop:'1.5rem', paddingTop:'1rem', borderTop:'1px solid var(--border)' }}>
                  <div style={{ fontSize:'0.75rem', color:'var(--text-muted)', marginBottom:'0.75rem', textTransform:'uppercase', letterSpacing:'0.05em' }}>Taxa de investimento</div>
                  <div style={{ fontSize:'1.5rem', fontWeight:600, color:'var(--blue-dark)' }}>
                    {totalEntradas ? ((totalInvest/totalEntradas)*100).toFixed(1) : 0}%
                  </div>
                  <div style={{ fontSize:'0.75rem', color:'var(--text-muted)' }}>do total de entradas investido</div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
