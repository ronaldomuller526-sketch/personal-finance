import Dashboard from '@/components/Dashboard'

export default function PessoalPage() {
  return <Dashboard />
}
