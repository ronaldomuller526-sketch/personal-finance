'use client'
import { useState } from 'react'
import Link from 'next/link'

const METAS_INICIAIS = [
  { nome:'Reserva de Emergência', meta:30000, atual:0, cor:'#1D9E75' },
  { nome:'Viagem Internacional',  meta:15000, atual:0, cor:'#378ADD' },
  { nome:'Investimentos Anuais',  meta:50000, atual:0, cor:'#533AB7' },
  { nome:'Reforma Apartamento',   meta:80000, atual:0, cor:'#BA7517' },
]

export default function MetasPage() {
  const [metas, setMetas] = useState(METAS_INICIAIS)
  const [editing, setEditing] = useState<number|null>(null)
  const [tempVal, setTempVal] = useState('')

  function atualizar(i: number) {
    const v = parseFloat(tempVal)
    if (!isNaN(v)) { const n=[...metas]; n[i]={...n[i],atual:v}; setMetas(n) }
    setEditing(null); setTempVal('')
  }

  function fmtR(v: number) { return 'R$ '+v.toLocaleString('pt-BR',{minimumFractionDigits:0,maximumFractionDigits:0}) }

  return (
    <div style={{minHeight:'100vh'}}>
      <div className="header">
        <div className="header-logo">💰 <span>Metas 2026</span></div>
        <Link href="/" className="btn-ghost">← Início</Link>
      </div>
      <div className="main">
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:'1.5rem'}}>
          <div>
            <h2 style={{fontSize:'1.1rem',fontWeight:600}}>Metas & Planejamento 2026</h2>
            <p style={{fontSize:'.825rem',color:'var(--text-muted)',marginTop:'.25rem'}}>Clique no valor atual para editar</p>
          </div>
        </div>
        <div className="metas-grid">
          {metas.map((m,i) => {
            const pct = Math.min((m.atual/m.meta)*100,100)
            return (
              <div key={m.nome} className="meta-card">
                <div style={{display:'flex',alignItems:'center',gap:'.5rem',marginBottom:'.75rem'}}>
                  <div style={{width:10,height:10,borderRadius:'50%',background:m.cor,flexShrink:0}}></div>
                  <div style={{fontWeight:500}}>{m.nome}</div>
                </div>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:'.8rem',color:'var(--text-muted)',marginBottom:'.5rem'}}>
                  <span>Meta: {fmtR(m.meta)}</span>
                  {editing===i ? (
                    <input type="number" value={tempVal} onChange={e=>setTempVal(e.target.value)}
                      onBlur={()=>atualizar(i)} onKeyDown={e=>e.key==='Enter'&&atualizar(i)} autoFocus
                      style={{width:100,padding:'.2rem .4rem',border:'1px solid var(--green)',borderRadius:4,fontFamily:'var(--font)',fontSize:'.8rem'}} />
                  ) : (
                    <span style={{cursor:'pointer',color:'var(--text)',fontWeight:500,borderBottom:'1px dashed var(--border)'}}
                      onClick={()=>{setEditing(i);setTempVal(String(m.atual))}}>
                      Atual: {fmtR(m.atual)}
                    </span>
                  )}
                </div>
                <div className="meta-bar-wrap"><div className="meta-bar" style={{width:`${pct.toFixed(0)}%`,background:m.cor}}></div></div>
                <div style={{fontSize:'.75rem',color:'var(--text-muted)'}}>{pct.toFixed(1)}% · Faltam {fmtR(Math.max(m.meta-m.atual,0))}</div>
              </div>
            )
          })}
        </div>
        <div className="chart-card" style={{marginTop:'1.5rem'}}>
          <div className="chart-card-header"><span className="chart-card-title">Resumo do progresso</span></div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:'1rem',textAlign:'center'}}>
            <div><div style={{fontSize:'.7rem',color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:'.4rem'}}>Total das metas</div><div style={{fontSize:'1.3rem',fontWeight:600}}>{fmtR(metas.reduce((s,m)=>s+m.meta,0))}</div></div>
            <div><div style={{fontSize:'.7rem',color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:'.4rem'}}>Acumulado</div><div style={{fontSize:'1.3rem',fontWeight:600,color:'var(--green-dark)'}}>{fmtR(metas.reduce((s,m)=>s+m.atual,0))}</div></div>
            <div><div style={{fontSize:'.7rem',color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:'.4rem'}}>Progresso</div><div style={{fontSize:'1.3rem',fontWeight:600,color:'var(--blue-dark)'}}>{(metas.reduce((s,m)=>s+m.atual,0)/metas.reduce((s,m)=>s+m.meta,0)*100||0).toFixed(1)}%</div></div>
          </div>
        </div>
      </div>
    </div>
  )
}
