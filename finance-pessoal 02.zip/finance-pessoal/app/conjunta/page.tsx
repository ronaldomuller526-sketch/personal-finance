import Dashboard from '@/components/Dashboard'
export default function ConjuntaPage() {
  return <Dashboard perfil="conjunta" />
}
